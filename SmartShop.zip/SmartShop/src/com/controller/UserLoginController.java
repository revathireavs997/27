package com.controller;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.dao.ProductDao;
import com.dao.UserDao;
import com.service.AuthenticationService;

@Component
@Controller
@RequestMapping("/user")
public class UserLoginController 
{
	@Autowired
	private AuthenticationService authenticateService;
	private static Logger log = Logger.getLogger(UserLoginController.class);
	@RequestMapping(value = "/validate", method = RequestMethod.POST)
	public ModelAndView validateUser(@RequestParam("username")String username, @RequestParam("password")String password,HttpSession session) 
	{
		String msg = "";

		boolean isValid = authenticateService.findUser(username, password);


		log.info("Is user valid?= " + isValid);

		System.out.println("In the controller..");

		if(isValid)
		{

			session.setAttribute("name", username);
			List<ProductDao> listProduct =  authenticateService.fetchProduct();

			int size = listProduct.size();
	   		 
		       String str[][] = new String[size][9];
		       	
		       	int i = 0;
		       	for (ProductDao st : listProduct)
		       	{
		       	
			       	  str[i][0] = new String(Integer.toString(st.getId()));
			       	  str[i][1] = new String(st.getProductRack());
			       	  str[i][2] = new String(st.getProductName());
			       	  str[i][6] = new String(st.getProductImage());
			       	  
			          if (st.getNoOfItems() < 10)
			              str[i][3] = "0"+ new String (Integer.toString(st.getNoOfItems()));
			          else
			              str[i][3] = new String (Integer.toString(st.getNoOfItems())); 
	
	
			          if (st.getDateOfManf() < 10)
			              str[i][4] = "0" + new String (Integer.toString(st.getDateOfManf()));
			          else       
			        	  str[i][4] = new String (Integer.toString(st.getDateOfManf()));
	
			          if (st.getDateOfExpiry() < 10)
			              str[i][5] = "0" + new String (Integer.toString(st.getDateOfExpiry()));
			          else
			        	  str[i][5] = new String (Integer.toString(st.getDateOfExpiry()));
	
			          
			         
			          i++;
		       	
		       	}


		       	return new ModelAndView("userResult","productList",str); 
		}
		else
		{
			msg = "Invalid credentials";
			return new ModelAndView("userIndex", "output", msg);
		}


	}
	@RequestMapping(value = "/userLogout", method = RequestMethod.GET)
	public ModelAndView logoutUser()
	{
		String msg = "You have been Logout Successfully";
		return new ModelAndView("userLogout","output",msg);

	}
	@RequestMapping(value = "/userIndex", method = RequestMethod.GET)
	public ModelAndView loginUser()
	{

		return new ModelAndView("userIndex");

	}  
	@RequestMapping(value = "/userRegistrationProcess", method = RequestMethod.POST)
	public ModelAndView registerUser(@RequestParam("fname")String first_name,@RequestParam("lname")String last_name,@RequestParam("age")int age,@RequestParam("gender")String gender,@RequestParam("contact")String contact_number, @RequestParam("userid")String userid,@RequestParam("pwd")String password)
	{
		UserDao u = new UserDao();

		u.setFirst_name(first_name);
		u.setLast_name(last_name);
		u.setAge(age);
		u.setGender(gender);
		u.setContact_number(contact_number);
		u.setUserid(userid);
		u.setPassword(password);


		boolean isValid = authenticateService.registerUser(u);
		System.out.println("In the controller..");

		if(isValid)
		{

			return new ModelAndView("userIndex" );	
		}
		else
		{
			System.out.println("register again!!!");
			return new ModelAndView("userRegistration");
		}


	}
	@RequestMapping(value = "/userRegistration", method = RequestMethod.GET)
	public ModelAndView registerUser()
	{

		return new ModelAndView("userRegistration");

	}  
	@RequestMapping(value = "/viewProduct", method = RequestMethod.GET)
	public ModelAndView viewProduct() {

		return new ModelAndView("viewProduct");

	}

} 

