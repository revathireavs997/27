package com.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dao.ManagerDao;
import com.dao.ProductDao;
import com.service.AuthenticationService;

@Component
@Controller
@RequestMapping("/manager")
public class ManagerLoginController {

	@Autowired
	private AuthenticationService authenticateService; 

	private static Logger log = Logger.getLogger(ManagerLoginController.class);

	@RequestMapping(value = "/validate", method = RequestMethod.POST)
	public ModelAndView validateUser(@RequestParam("username") String username,
			@RequestParam("password") String password, HttpSession session) {
		String msg = "";

		boolean isValid = authenticateService.findManager(username, password);

		log.info("Is user valid?= " + isValid);

		System.out.println("In the controller..");

		if (isValid) {

			session.setAttribute("name", username);
			List<ProductDao> lstProduct = authenticateService.fetchProduct();

			int size = lstProduct.size();

			String str[][] = new String[size][7];

			int i = 0;
			for (ProductDao st : lstProduct) {

				str[i][0] = new String(Integer.toString(st.getId()));

				str[i][1] = new String(st.getProductRack());
				str[i][2] = new String(st.getProductName());

				if (st.getNoOfItems() < 10)
					str[i][3] = "0" + new String(Integer.toString(st.getNoOfItems()));
				else
					str[i][3] = new String(Integer.toString(st.getNoOfItems()));

				if (st.getDateOfManf() < 10)
					str[i][4] = "0" + new String(Integer.toString(st.getDateOfManf()));
				else
					str[i][4] = new String(Integer.toString(st.getDateOfManf()));

				if (st.getDateOfExpiry() < 10)
					str[i][5] = "0" + new String(Integer.toString(st.getDateOfExpiry()));
				else
					str[i][5] = new String(Integer.toString(st.getDateOfExpiry()));

				str[i++][6] = new String(st.getProductImage());
			}

			System.out.println("In the controller..");
			return new ModelAndView("adminResult", "productList", str);
		} else {
			msg = "Invalid credentials";
			return new ModelAndView("adminIndex", "output", msg);
		}

	}

	@RequestMapping(value = "/adminLogout", method = RequestMethod.GET)
	public ModelAndView logoutUser() {
		String msg = "You have been Logout Successfully";
		return new ModelAndView("adminLogout");

	}

	@RequestMapping(value = "/adminIndex", method = RequestMethod.GET)
	public ModelAndView loginUser() {

		return new ModelAndView("adminIndex");

	}

	@RequestMapping(value = "/addProduct", method = RequestMethod.POST)
	public ModelAndView addProduct() {

		return new ModelAndView("addProduct");

	}

	@RequestMapping(value = "/viewProduct", method = RequestMethod.GET)
	public ModelAndView viewProduct() {

		return new ModelAndView("viewProduct");

	}

	@RequestMapping(value = "/editProduct", method = RequestMethod.GET)
	public ModelAndView editProduct() {

		return new ModelAndView("editProduct");

	}

	@RequestMapping(value = "/adminRegistration", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView registerUser1(@RequestParam("t2") String ProductRack, @RequestParam("t3") String ProductName,
			@RequestParam("t4") int NoOfItems, @RequestParam("t5") int DateOfManf, @RequestParam("t6") int DateOfExpiry,
			@RequestParam("t7") String ProductImage) {
		System.out.println("Hello ");
		ProductDao u1 = new ProductDao();
	
		u1.setProductRack(ProductRack);
		u1.setProductName(ProductName);
		u1.setNoOfItems(NoOfItems);
		u1.setDateOfManf(DateOfManf);
		u1.setDateOfExpiry(DateOfExpiry);
		u1.setProductImage(ProductImage);

		boolean isValid = authenticateService.insertProduct(u1);
		System.out.println("In the controller.. ");

		if (isValid) {
			List<ProductDao> lstProduct = authenticateService.fetchProduct();

			int size = lstProduct.size();

			String str[][] = new String[size][7];

			int i = 0;
			for (ProductDao st : lstProduct) {

				str[i][0] = new String(Integer.toString(st.getId()));
				
				
				str[i][1] = new String(st.getProductRack());
				str[i][2] = new String(st.getProductName());

				if (st.getNoOfItems() < 10)
					str[i][3] = "0" + new String(Integer.toString(st.getNoOfItems()));
				else
					str[i][3] = new String(Integer.toString(st.getNoOfItems()));

				if (st.getDateOfManf() < 10)
					str[i][4] = "0" + new String(Integer.toString(st.getDateOfManf()));
				else
					str[i][4] = new String(Integer.toString(st.getDateOfManf()));

				if (st.getDateOfExpiry() < 10)
					str[i][5] = "0" + new String(Integer.toString(st.getDateOfExpiry()));
				else
					str[i][5] = new String(Integer.toString(st.getDateOfExpiry()));

				str[i++][6] = new String(st.getProductImage());
			}

			System.out.println("In the controller..");
			return new ModelAndView("adminResult", "productList", str);

		} else {
			System.out.println("register again!!!");
			return new ModelAndView("addProduct");
		}
	}

	@RequestMapping(value = "/deleteCourse", method = RequestMethod.GET)
	public ModelAndView validateUsr1(@RequestParam("t1") int id) {

		ProductDao s = new ProductDao();
		boolean isValid = authenticateService.delCourse(id);
		log.info("Is user valid?= " + isValid);

		if (isValid == true) {

			List<ProductDao> lstProduct = authenticateService.fetchProduct();

			int size = lstProduct.size();

			String str[][] = new String[size][7];

			int i = 0;
			for (ProductDao st : lstProduct) {

				str[i][0] = new String(Integer.toString(st.getId()));

				str[i][1] = new String(st.getProductRack());
				str[i][2] = new String(st.getProductName());

				if (st.getNoOfItems() < 10)
					str[i][3] = "0" + new String(Integer.toString(st.getNoOfItems()));
				else
					str[i][3] = new String(Integer.toString(st.getNoOfItems()));

				if (st.getDateOfManf() < 10)
					str[i][4] = "0" + new String(Integer.toString(st.getDateOfManf()));
				else
					str[i][4] = new String(Integer.toString(st.getDateOfManf()));

				if (st.getDateOfExpiry() < 10)
					str[i][5] = "0" + new String(Integer.toString(st.getDateOfExpiry()));
				else
					str[i][5] = new String(Integer.toString(st.getDateOfExpiry()));

				str[i++][6] = new String(st.getProductImage());
			}

			System.out.println("In the controller..");
			return new ModelAndView("adminResult", "productList", str);

		}

		else {
			List<ProductDao> lstProduct = authenticateService.fetchProduct();

			int size = lstProduct.size();

			String str[][] = new String[size][7];

			int i = 0;
			for (ProductDao st : lstProduct) {

				str[i][0] = new String(Integer.toString(st.getId()));

				str[i][1] = new String(st.getProductRack());
				str[i][2] = new String(st.getProductName());

				if (st.getNoOfItems() < 10)
					str[i][3] = "0" + new String(Integer.toString(st.getNoOfItems()));
				else
					str[i][3] = new String(Integer.toString(st.getNoOfItems()));

				if (st.getDateOfManf() < 10)
					str[i][4] = "0" + new String(Integer.toString(st.getDateOfManf()));
				else
					str[i][4] = new String(Integer.toString(st.getDateOfManf()));

				if (st.getDateOfExpiry() < 10)
					str[i][5] = "0" + new String(Integer.toString(st.getDateOfExpiry()));
				else
					str[i][5] = new String(Integer.toString(st.getDateOfExpiry()));

				str[i++][6] = new String(st.getProductImage());
			}

			System.out.println("In the controller..");
			return new ModelAndView("adminResult", "productList", str);

		}

	}

	@RequestMapping(value = "/editProcess", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView registerUsr2(@RequestParam("t1") int ProductId, @RequestParam("t2") String ProductRack,
			@RequestParam("t3") String ProductName, @RequestParam("t4") int NoOfItems,
			@RequestParam("t5") int DateOfManf, @RequestParam("t6") int DateOfExpiry,
			@RequestParam("t7") String ProductImage) {
		System.out.println("Hello ");
		ProductDao u1 = new ProductDao();
		u1.setId(ProductId);
		u1.setProductRack(ProductRack);
		u1.setProductName(ProductName);
		u1.setNoOfItems(NoOfItems);
		u1.setDateOfManf(DateOfManf);
		u1.setDateOfExpiry(DateOfExpiry);
		u1.setProductImage(ProductImage);

		boolean isValid = authenticateService.editProduct(u1);
		System.out.println("In the controller.. ");

		if (isValid) {
			List<ProductDao> lstProduct = authenticateService.fetchProduct();

			int size = lstProduct.size();

			String str[][] = new String[size][7];

			int i = 0;
			for (ProductDao st : lstProduct) {

				str[i][0] = new String(Integer.toString(st.getId()));

				str[i][1] = new String(st.getProductRack());
				str[i][2] = new String(st.getProductName());

				if (st.getNoOfItems() < 10)
					str[i][3] = "0" + new String(Integer.toString(st.getNoOfItems()));
				else
					str[i][3] = new String(Integer.toString(st.getNoOfItems()));

				if (st.getDateOfManf() < 10)
					str[i][4] = "0" + new String(Integer.toString(st.getDateOfManf()));
				else
					str[i][4] = new String(Integer.toString(st.getDateOfManf()));

				if (st.getDateOfExpiry() < 10)
					str[i][5] = "0" + new String(Integer.toString(st.getDateOfExpiry()));
				else
					str[i][5] = new String(Integer.toString(st.getDateOfExpiry()));

				str[i++][6] = new String(st.getProductImage());
			}

			System.out.println("In the controller..");
			return new ModelAndView("adminResult", "productList", str);

		} else {
			System.out.println("register again!!!");
			return new ModelAndView("editProduct");
		}
	}

	@RequestMapping(value = "/registerProcess", method = RequestMethod.POST)

	public ModelAndView registerUsr(@RequestParam("fname") String first_name, @RequestParam("lname") String last_name,
			@RequestParam("age") int age, @RequestParam("gender") String gender,
			@RequestParam("contact") String contact_number, @RequestParam("userid") String userid,
			@RequestParam("pwd") String password) 
			{
				ManagerDao u = new ManagerDao();
		
				u.setFirst_name(first_name);
				u.setLast_name(last_name);
				u.setAge(age);
				u.setGender(gender);
				u.setContact_number(contact_number);
				u.setUserid(userid);
				u.setPassword(password);
		
				boolean isValid = authenticateService.registerManager(u);
				System.out.println("In the controller..");

				if (isValid) 
				{
		
					return new ModelAndView("adminIndex");
				} 
				else 
				{
					System.out.println("register again!!!");
					return new ModelAndView("adminRegistration");
				}

			}
	
	@RequestMapping(value = "/adminRegistration1", method = RequestMethod.GET)
	public ModelAndView adminRegistration() {

		return new ModelAndView("adminRegistration");

	}
	
}