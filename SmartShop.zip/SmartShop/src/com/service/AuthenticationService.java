package com.service;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.dao.ManagerDao;
//import com.dao.ManagerDao;
import com.dao.ProductDao;
import com.dao.UserDao;

public class AuthenticationService 
{

	private HibernateTemplate hibernateTemplate;
	private static Logger log = Logger.getLogger(AuthenticationService.class);

	private AuthenticationService() 
	{
		
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate)

	{
		this.hibernateTemplate = hibernateTemplate;
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	public boolean findUser(String uname, String upwd)

	{

		log.info("Checking the user in the database");

		boolean isValidUser = false;

		// String sqlQuery = "from User where name='"+uname + "' and
		// password='"+upwd+"'";

		// System.out.println("In the authentication service...user entered data
		// " + uname + " pwd "+upwd);

		try 
		{

			// String sqlQuery = "from User1";
			String sqlQuery = "from UserDao u where u.userid=? and u.password=?";

			List<UserDao> userObj = (List<UserDao>) hibernateTemplate.find(sqlQuery, uname, upwd);

			System.out.println("After select query from session..");

			if (userObj != null)
			{
				System.out.println("userObject is not null... ");
				for (UserDao obj : userObj) 
				{
					System.out.println(" Name " + obj.getUserid() + " Password " + obj.getPassword());

				}

			}

			if (userObj != null && userObj.size() > 0)
			{
				// log.info("Id= " + userObj.get(0)).getId() + ", Name= " +
				// userObj.get(0).getName() + ", Password= " +
				// userObj.get(0).getPassword());
				isValidUser = true;
			}
		} 
		catch (Exception e)
		{
			isValidUser = false;
			log.error("An error occurred while fetching the user details from the database", e);
			System.out.println(e);
		}
		return isValidUser;
	}

	public boolean registerUser(UserDao u)
	{
		try 
		{

			System.out.println("Before Entering Data");
			boolean isValidUser = true;

			hibernateTemplate.save(u);

			System.out.println("After Entering Data");

			return isValidUser;
		}
		catch (Exception ex) 
		{
			System.out.println(ex);
			ex.printStackTrace();

		}
		return false;
	}

	public List fetchProduct()
	{
		log.info("Checking the user in the database");
		List<ProductDao> userObj = null;

		try 
		{

			String sqlQuery = "from ProductDao ";

			userObj = (List<ProductDao>) hibernateTemplate.find(sqlQuery);

			System.out.println("After select query from session..");

			if (userObj != null) 
			{
				System.out.println("userObject is not null... ");
				for (ProductDao obj : userObj)
				{

					return userObj;
				}

			}
		} 
		catch (Exception e) 
		{

			log.error("An error occurred while fetching the user details from the database", e);
			System.out.println(e);

		}
		return userObj;

	}

	public boolean findManager(String uname, String upwd)

	{

		log.info("Checking the manager in the database");

		boolean isValidManager = false;

		try 
		{

			String sqlQuery = "from ManagerDao u where u.userid=? and u.password=?";

			List<ManagerDao> managerObj = (List) hibernateTemplate.find(sqlQuery, uname, upwd);

			System.out.println("After select query from session..");

			if (managerObj != null) 
			{
				System.out.println("managerObject is not null... ");
				for (ManagerDao obj : managerObj) 
				{
					System.out.println(" Name " + obj.getUserid() + " Password " + obj.getPassword());

				}

			}

			if (managerObj != null && managerObj.size() > 0)
			{
				// log.info("Id= " + managerObj.get(0)).getId() + ", Name= " +
				// managerObj.get(0).getName() + ", Password= " +
				// managerObj.get(0).getPassword());
				isValidManager = true;
			}
		} 
		catch (Exception e)
		{
			isValidManager = false;
			log.error("An error occurred while fetching the manager details from the database", e);
			System.out.println(e);
		}
		return isValidManager;
	}

	public boolean registerManager(ManagerDao u)
	{
		try 
		{

			System.out.println("Before Entering Data");
			boolean isValidManager = true;

			hibernateTemplate.save(u);

			System.out.println("After Entering Data");

			return isValidManager;
		} 
		catch (Exception ex) 
		{
			System.out.println(ex);
			ex.printStackTrace();

		}
		return false;
	}

	public boolean insertProduct(ProductDao u1) {
		try {

			System.out.println("Before Entering Data");
			boolean isValidUser = true;

			hibernateTemplate.save(u1);

			System.out.println("After Entering Data");

			return isValidUser;
		} catch (Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();

		}
		return false;
	}

	public boolean delCourse(int c) {
		log.info("Checking the user in the database");
		boolean isValid = true;
		try {

			hibernateTemplate.bulkUpdate("delete from ProductDao where id=" + c);

			return isValid;
		}

		catch (Exception e) {
			System.out.println("In the catch block of delete..." + e);
			isValid = false;
			e.printStackTrace();
			log.error("An error occurred while fetching the user details from the database", e);
		}

		return isValid;
	}

	public boolean editProduct(ProductDao u1) {
		try {

			System.out.println("Before Entering Data");
			boolean isValidUser = true;

			// hibernateTemplate.bulkUpdate ("DELETE FROM SmartProduct WHERE
			// id="+u1.getId());
			// hibernateTemplate.save(u1);

			String sqlQuery = "UPDATE ProductDao SET ProductRack =?, ProductName=?,NoOfItems=?, DateOfManf=?, DateOfExpiry=? WHERE id=?";
			hibernateTemplate.bulkUpdate(sqlQuery, u1.getProductRack(), u1.getProductName(), u1.getNoOfItems(),
					u1.getDateOfManf(), u1.getDateOfExpiry(), u1.getId());

			System.out.println("After Entering Data");

			return isValidUser;
		} catch (Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();

		}
		return false;
	}

}